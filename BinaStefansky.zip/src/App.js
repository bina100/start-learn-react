import './App.css';
import AppHooks from './hooks_component/appHooks';
import ToysList from './hw_component/toysList';

function App() {
  return (
    <div className="App">
      {/* <ToysList/> */}
      <hr/>
      <AppHooks/>
    </div>
  );
}

export default App;
